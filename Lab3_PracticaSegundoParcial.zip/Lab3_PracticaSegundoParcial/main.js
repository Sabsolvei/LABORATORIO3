"use strict";
var txtId;
var txtNombre;
var txtEdad;
var txtPatas;
var selectTipo;
var btnAgregar;
var table;
var filterTable;
var tBodyFiltro;
var btnFiltro;
var selectTipoFiltro;
var mod;
// var lblMensaje;
// var xhr;
// var loading;
var mascotasArray;
$(function () {
    txtId = $('#id');
    txtNombre = $('#nombre');
    txtEdad = $('#edad');
    txtPatas = $('#patas');
    selectTipo = $('.tipo');
    table = $('#tabla');
    btnAgregar = $('#agregar');
    filterTable = $('#tablaFiltros');
    tBodyFiltro = $('#tBodyFiltro');
    btnFiltro = $('#filtro');
    selectTipoFiltro = $("#tipoFiltro");
    btnAgregar.on("click", AgregarMascotas);
    //lblMensaje = $('#mensaje');
    //loading = $('#loading');
    //localStorage.clear();
    //txtId.keypress(function(){restaurarBorderColor();});
    //txtNombre.keypress(function(){restaurarBorderColor();});
    for (var i = 0; i < 6; i++) {
        selectTipo.append("<option value=" + i + ">" + practicaMascotas.animales[i] + "</option>");
    }
    selectTipo.change(function () {
        if (selectTipo.val() >= 0 && selectTipo.val() < 4) {
            txtPatas.val(4);
        }
        else {
            txtPatas.val(0);
        }
    });
    var filtrado;
    btnFiltro.on("click", tablaFiltrada);
    TraerMascotas();
});
//btnAgregar.on("click", mod = function(){ ModificarClick(id) });
function filtrar(tipo) {
    var arrayFiltradoPorTipo = filtrarPorTipo(tipo);
    var arrayFiltrado = filtrarPorItems(arrayFiltradoPorTipo);
    return arrayFiltrado;
}
function filtrarPorTipo(tipo) {
    return mascotasArray
        .filter(function (mascota) {
        return mascota.tipo == tipo;
    });
}
function filtrarPorItems(arrayFiltrado) {
    if ($('#chkNombre').is(':checked') && $('#chkEdad').is(':checked')) {
        arrayFiltrado = filtrarPorNombreEdad(arrayFiltrado);
    }
    if ($('#chkNombre').is(':checked')) {
        arrayFiltrado = filtrarPorNombre(arrayFiltrado);
    }
    if ($('#chkEdad').is(':checked')) {
        arrayFiltrado = filtrarPorEdad(arrayFiltrado);
    }
    return arrayFiltrado;
}
function filtrarPorNombreEdad(arrayFiltrado) {
    return arrayFiltrado
        .map(function (mascota) {
        return { nombre: mascota.nombre, edad: mascota.edad };
    });
}
function filtrarPorNombre(arrayFiltrado) {
    return arrayFiltrado
        .map(function (mascota) {
        return mascota.nombre;
    });
}
function filtrarPorEdad(arrayFiltrado) {
    return arrayFiltrado
        .map(function (mascota) {
        return mascota.edad;
    });
}
function tablaFiltrada() {
    TraerMascotas();
    var arrayFiltrado = filtrar(practicaMascotas.animales[selectTipoFiltro.val()]);
    for (var index = 0; index < arrayFiltrado.length; index++) {
        tBodyFiltro.append("<tr><td>" + arrayFiltrado[index] + "<td><tr>");
    }
}
function Eliminar(id) {
    TraerMascotas();
    mascotasArray.splice(id, 1);
    localStorage.setItem("mascotas", JSON.stringify(mascotasArray));
    TraerMascotas();
}
function TraerMascotas() {
    mascotasArray = [];
    var mascotasDelLocal = localStorage.getItem("mascotas");
    mascotasArray = JSON.parse(mascotasDelLocal);
    table.html("<tr><th>Nombre</th><th>Edad</th><th>Patas</th><th>Tipo</th><th>Accion</th></tr>");
    //loading.html("");
    for (var index = 0; index < mascotasArray.length; index++) {
        table.append("<tr><td name=n " + index + "> " + mascotasArray[index].nombre + "</td>\n                    <td name=n " + index + ">" + mascotasArray[index].edad + "</td>\n                    <td name=n " + index + ">" + mascotasArray[index].patas + "</td>\n                    <td name=n " + index + ">" + mascotasArray[index].tipo + "</td>\n                    <td><input type=button id= " + index + " value=Eliminar onclick=Eliminar(" + index + ")>\n                    <input type=button id= " + index + " value=Modificar onclick=Modificar(\"" + index + "\")></td></tr>");
    }
}
function AgregarMascotas() {
    if (selectTipo.val() != "" && txtNombre.val() != "" && txtEdad.val() != "" && txtPatas.val() != "") {
        var masc = new practicaMascotas.Mascota(txtNombre.val(), txtEdad.val(), txtPatas.val(), selectTipo.val());
        if (mascotasArray == null) {
            mascotasArray = [];
            mascotasArray.push(JSON.parse(masc.toJson()));
        }
        else {
            mascotasArray.push(JSON.parse(masc.toJson()));
        }
        localStorage.setItem("mascotas", JSON.stringify(mascotasArray));
        //localStorage.mascota1 = JSON.stringify(masc);
        alert("Se guardo la mascota");
        //restaurarTexto();
        //MostrarMensaje("Se guardo la Mascotas");
    }
    else {
        //MostrarMensajeError("Debe ingresar nombre y apellido");
        //restaurarTexto();
    }
    TraerMascotas();
}
function Modificar(id) {
    txtNombre.val(mascotasArray[id].nombre);
    txtEdad.val(mascotasArray[id].edad);
    txtPatas.val(mascotasArray[id].patas);
    selectTipo.val(practicaMascotas.animales[mascotasArray[id].tipo]);
    btnAgregar.attr("value", "Modificar");
    btnAgregar.off("click", AgregarMascotas);
    btnAgregar.on("click", mod = function () { ModificarClick(id); });
}
function ModificarClick(id) {
    var masc = new practicaMascotas.Mascota(txtNombre.val(), txtEdad.val(), txtPatas.val(), selectTipo.val());
    mascotasArray[id] = JSON.parse(masc.toJson());
    localStorage.setItem("mascotas", JSON.stringify(mascotasArray));
    restaurarTexto();
    TraerMascotas();
    btnAgregar.attr("value", "Agregar");
    btnAgregar.off("click", mod);
    btnAgregar.on("click", AgregarMascotas);
}
// function AgregarMascotaserver()
// {
//     $.ajax({
//         url : "http://localhost:3000/agregarMascotas",
//         data : { nombre: txtA.val(), apellido: txtB.val()},
//         type : "POST",
//         datatype : "text",
//         success : function(respuesta)
//         {
//             lblMensaje.html(respuesta).hide().fadeIn(2000).fadeOut(2000);
//         }
//     });
//     TraerMascotas();
//     restaurarTexto();
// }
// function EliminarMascotaserver(id)
// {
//     $.ajax({
//         url: "http://localhost:3000/eliminarMascotas",
//         data: {indice : id},
//         type : "POST",
//         dataType : "text",
//         success : function(respuesta)
//                 {
//                     lblMensaje.html(respuesta).hide().fadeIn(2000).fadeOut(2000);
//                 }
//     });
//     TraerMascotas();
// }
// function Eliminar(id) 
// {
//     EliminarMascotaserver(id);
//     MostrarMensaje("Se elimino la Mascotas"); 
// }
// function MostrarMensajeError(mensajeDeError)
// {
//     txtA.css("borderColor","red");
//     txtB.css("borderColor","red");
//     lblMensaje.css("color", "#FA2222");
//     lblMensaje.html(mensajeDeError);
// }
// function MostrarMensaje(mensaje)
// {
//     lblMensaje.css("color", "gray");
//     lblMensaje.html(mensaje);
// }
// function restaurarBorderColor() 
// {
//     txtA.css("borderColor","");
//     txtB.css("borderColor","");
//     lblMensaje.html("");
// }
function restaurarTexto() {
    txtNombre.val("");
    txtEdad.val("");
    txtPatas.val("");
    selectTipo.val("");
}
// function CargarMascotas(respuesta) {
//     var Mascotas = respuesta;
//     lblMensaje.html("");
//     table.html("<tr><th>Nombre</th><th>Apellido</th><th>Accion</th></tr>");
//     for (var index= 0; index < Mascotas.length; index++) 
//     {
//         table.append("<tr><td name=n"+index+">"+Mascotas[index].nombre+"</td><td name=a"+index+">"+Mascotas[index].apellido+"</td>"+
//         "<td><input type=button id= "+index+" value=Eliminar onclick=Eliminar("+index+")>"+
//         "<input type=button id= "+index+" value=Modificar onclick=Modificar("+index+")></td></tr>");
//     }
// }
// function CargarMascotas()
// {
//     table.html("");
//     table.style = "block";
//     var Mascotas = JSON.parse(xhr.response);
//     for (var index= 0; index < Mascotas.length; index++) 
//     {
//         table.html("<tr><td name=n"+index+">"+Mascotas[index].nombre+"</td><td name=a"+index+">"+Mascotas[index].apellido+"</td>"+
//         "<td><input type=button id= "+index+" value=Eliminar onclick=Eliminar("+index+")>"+
//         "<input type=button id= "+index+" value=Modificar onclick=Modificar("+index+")></td></tr>");
//     }
// } 
