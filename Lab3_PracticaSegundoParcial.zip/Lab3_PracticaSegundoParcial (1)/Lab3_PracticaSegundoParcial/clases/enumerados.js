"use strict";
var practicaMascotas;
(function (practicaMascotas) {
    var animales;
    (function (animales) {
        animales[animales["todos"] = 0] = "todos";
        animales[animales["perro"] = 1] = "perro";
        animales[animales["gato"] = 2] = "gato";
        animales[animales["reptil"] = 3] = "reptil";
        animales[animales["roedor"] = 4] = "roedor";
        animales[animales["ave"] = 5] = "ave";
        animales[animales["pez"] = 6] = "pez";
    })(animales = practicaMascotas.animales || (practicaMascotas.animales = {}));
})(practicaMascotas || (practicaMascotas = {}));
