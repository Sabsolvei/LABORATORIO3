namespace practicaMascotas {

    export enum animales{
        todos,
        perro, 
        gato, 
        reptil, 
        roedor, 
        ave, 
        pez
    }
}
