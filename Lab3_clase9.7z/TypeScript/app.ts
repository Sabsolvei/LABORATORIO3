//npm install -g typescript 
//tsc -init (agrega archivo de config de typescript)
//tsc app (transpila a js y genera el archivo donde estoy parado)
//tsc --init y luego tcs --watch o tsc -w (permite que traspile mientras desarrollo y guardo) - para cancelar el watch: ctrl+C
//pagina TypeScript , se puede codear en typeScript e instantaneamnete transpila a javascript
//npm install jquery (para tener las librerias de jquery)
//npm install @type/jquery (traduce typescript a jquery)

///<reference path='node_modules/@types/jquery/index.d.ts'/>
console.log("Hola mundo!!!!");
$(function(){
    $('#txt').val("hola mundo");
});

