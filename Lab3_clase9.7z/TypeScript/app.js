"use strict";
//npm install -g typescript 
//tsc -init (agrega archivo de config de typescript)
//tsc app (transpila a js y genera el archivo donde estoy parado)
//tsc --init y luego tcs --watch o tsc -w (permite que traspile mientras desarrollo y guardo)
//pagina TypeScript , se puede codear en typeScript e instantaneamnete transpila a javascript
console.log("Hola mundo!!!!");
$(function () {
    $('#txt').val("hola mundo");
});
