"use strict";
var practicaMascotas;
(function (practicaMascotas) {
    var Animal = /** @class */ (function () {
        function Animal(nombre, edad, patas) {
            this._nombre = nombre;
            this._edad = edad;
            this._patas = patas;
        }
        Animal.prototype.toJson = function () {
            var json = "{\"nombre\": \"" + this._nombre + "\", \"edad\": \"" + this._edad + "\", \"patas\": \"" + this._patas + "\", ";
            return json;
        };
        return Animal;
    }());
    practicaMascotas.Animal = Animal;
})(practicaMascotas || (practicaMascotas = {}));
