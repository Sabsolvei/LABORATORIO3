///<reference path="animal.ts"/>
///<reference path="enumerados.ts"/>

namespace practicaMascotas {

    export class Mascota extends Animal 
    {

        private _tipo: animales;
        //private _id:number;

        constructor(nombre:string, edad:number, patas:number, tipo:animales)
        {    
            super(nombre, edad, patas);
            this._tipo = tipo;
            //this._id = id;
        }

        toJson(): string
        {
            //let json = JSON.stringify(this);
            let json = super.toJson() + `"tipo": "${animales[this._tipo]}"}`;
            return json;
        }

    }

}

