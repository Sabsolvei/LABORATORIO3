let txtId;
let txtNombre: any;
let txtEdad: any;
let txtPatas: any;
let selectTipo: any;
let btnAgregar: any;
let table: any;
let filterTable: any;
let tBodyFiltro: any;
let btnFiltro: any;
let selectTipoFiltro: any;
let checkNombre: any;
let checkEdad: any;
let checkPatas: any;
let checkTipo: any;
let txtPromedio: any;
let btnPromedio: any;
let mod: any; //funcion modificar
let mascotasArray: any;
// var lblMensaje;
// var xhr;
// var loading;


$(function () {

    txtId = $('#id');
    txtNombre = $('#nombre');
    txtEdad = $('#edad');
    txtPatas = $('#patas');
    selectTipo = $('.tipo');
    table = $('#tabla');
    btnAgregar = $('#agregar');
    filterTable = $('#tablaFiltros');
    tBodyFiltro = $('#tBodyFiltro')
    btnFiltro = $('#filtro');
    selectTipoFiltro = $("#tipoFiltro");

    txtPromedio =$("#txtPromedio");
    btnPromedio =$("#btnPromedio");

    checkNombre = $("#chkNombre");
    checkEdad = $("#chkEdad");
    checkPatas = $("#chkPatas");
    checkTipo = $("#chkTipo");
    //lblMensaje = $('#mensaje');
    //loading = $('#loading');
    //localStorage.clear();
   
    //txtId.keypress(function(){restaurarBorderColor();});
    //txtNombre.keypress(function(){restaurarBorderColor();});

    for (var i = 0; i < 7; i++) {
        selectTipo.append("<option value=" + i + ">" + practicaMascotas.animales[i] + "</option>");
    }

    selectTipo.change(function () {
        if (selectTipo.val() >= 0 && selectTipo.val() < 4) {
            txtPatas.val(4);
        }
        else if(selectTipo.val() == 4) {
            txtPatas.val(2);
        }
        else if(selectTipo.val() == 5) {
            txtPatas.val(0);
        }
        else if(selectTipo.val() == 8) {
            txtPatas.val("");
        }
    });

    let filtrado;
    btnAgregar.on("click", AgregarMascotas);
    btnFiltro.on("click", armarTablaFiltrada);
    selectTipoFiltro.on("change", armarTablaFiltrada);
    checkNombre.on("change", armarTablaFiltrada);
    checkEdad.on("change", armarTablaFiltrada);
    checkPatas.on("change", armarTablaFiltrada);
    checkTipo.on("change", armarTablaFiltrada);
    btnPromedio.on("click", calcularEdad);
    TraerMascotas();


});
//btnAgregar.on("click", mod = function(){ ModificarClick(id) });
// function filtrar(tipo: any) {
//     let arrayFiltradoPorTipo = filtrarPorTipo(tipo);
//     //let arrayFiltrado = filtrarPorItems(arrayFiltradoPorTipo);
//     return arrayFiltradoPorTipo;
// }

function traerNombres(arrayFiltrado: any) {
    return arrayFiltrado
        .map(function (mascota: any) {
            return mascota.nombre;
        });
}

function traerEdades(arrayFiltrado: any) {
    return arrayFiltrado
        .map(function (mascota: any) {
            return mascota.edad;
        });
}

function traerPatas(arrayFiltrado: any) {
    return arrayFiltrado
        .map(function (mascota: any) {
            return mascota.patas;
        });
}

function traerTipo(arrayFiltrado: any) {
    return arrayFiltrado
        .map(function (mascota: any) {
            return mascota.tipo;
        });
}

function filtrarPorTipo(tipo: any) {
    return mascotasArray
        .filter(function (mascota: any) {
            return mascota.tipo == tipo;
        });
}

function calcularEdad()
{
    
    TraerMascotas();
    let mascotas = mascotasArray;
    if (practicaMascotas.animales[selectTipoFiltro.val()] != "todos") {
        mascotas = filtrarPorTipo(practicaMascotas.animales[selectTipoFiltro.val()]);
    }
    if(mascotas != null && mascotas.length > 0){
        let acumEdad = mascotas[0].edad;
            mascotas
                .reduce(function(mascPrevia, mascActual){
                    acumEdad += mascActual.edad;
                    return mascActual;
                });
            txtPromedio.val(acumEdad/mascotas.length);
    }
    else{
        txtPromedio.val(0);
    }
    
}

function armarTablaFiltrada() {
    let tBodyFiltro = $("#tBodyFiltro");
    let tHeadFiltro = $("#tHeadFiltro");
    let tr = "<tr>";

    tBodyFiltro.html("");
    TraerMascotas();
    let mascotas = mascotasArray;
    if (practicaMascotas.animales[selectTipoFiltro.val()] != "todos") {
        mascotas = filtrarPorTipo(practicaMascotas.animales[selectTipoFiltro.val()]);
    }
    let mascotasNombre = traerNombres(mascotas);
    let mascotasEdad = traerEdades(mascotas);
    let mascotasPatas = traerPatas(mascotas);
    let mascotasTipo = traerTipo(mascotas);

    if (checkNombre.is(':checked')) {
        tr += "<th>Nombre</th>";
    }

    if (checkEdad.is(':checked')) {
        tr += "<th>Edad</th>";
    }

    if (checkPatas.is(':checked')) {
        tr += "<th>Patas</th>";
    }

    if (checkTipo.is(':checked')) {
        tr += "<th>Tipo</th>";
    }

    tr += "</tr>";

    tHeadFiltro.html(tr);

    for (var index = 0; index < mascotas.length; index++) {
        tr = "<tr>";

        if (checkNombre.is(':checked')) {
            tr += "<td>" + mascotasNombre[index] + "</td>";
        }

        if (checkEdad.is(':checked')) {
            tr += "<td>" + mascotasEdad[index] + "</td>";
        }

        if (checkPatas.is(':checked')) {
            tr += "<td>" + mascotasPatas[index] + "</td>";
        }

        if (checkTipo.is(':checked')) {
            tr += "<td>" + mascotasTipo[index] + "</td>";
        }

        tr += "</tr>";

        tBodyFiltro.append(tr);
    }

}


function Eliminar(id: number) {
    TraerMascotas();
    mascotasArray.splice(id, 1);
    localStorage.setItem("mascotas", JSON.stringify(mascotasArray));
    TraerMascotas();
}

function TraerMascotas() {
    mascotasArray = [];
    let mascotasDelLocal: string;
    mascotasDelLocal = localStorage.getItem("mascotas");
    mascotasArray = JSON.parse(mascotasDelLocal);

    table.html("<tr><th>Nombre</th><th>Edad</th><th>Patas</th><th>Tipo</th><th>Accion</th></tr>");
    //loading.html("");
    for (var index = 0; index < mascotasArray.length; index++) {
        table.append(
            `<tr><td name=n ${index}> ${mascotasArray[index].nombre}</td>
                    <td name=n ${index}>${mascotasArray[index].edad}</td>
                    <td name=n ${index}>${mascotasArray[index].patas}</td>
                    <td name=n ${index}>${mascotasArray[index].tipo}</td>
                    <td><input type=button id= ${index} value=Eliminar onclick=Eliminar(${index})>
                    <input type=button id= ${index} value=Modificar onclick=Modificar("${index}")></td></tr>`);
    }
}


function AgregarMascotas(): void {
    if (selectTipo.val() != "" && txtNombre.val() != "" && txtEdad.val() != "" && txtPatas.val() != "") {
        let masc: practicaMascotas.Mascota = new practicaMascotas.Mascota(txtNombre.val(), txtEdad.val(), txtPatas.val(), selectTipo.val());
        if (mascotasArray == null) {
            mascotasArray = [];
        }
        mascotasArray.push(JSON.parse(masc.toJson()));
        localStorage.setItem("mascotas", JSON.stringify(mascotasArray));
        //localStorage.mascota1 = JSON.stringify(masc);

        alert("Se guardo la mascota");

        //restaurarTexto();
        //MostrarMensaje("Se guardo la Mascotas");
    }
    else {
        //MostrarMensajeError("Debe ingresar nombre y apellido");
        //restaurarTexto();
    }
    TraerMascotas();
}

function Modificar(id: number) {

    txtNombre.val(mascotasArray[id].nombre);
    txtEdad.val(mascotasArray[id].edad);
    txtPatas.val(mascotasArray[id].patas);
    selectTipo.val(practicaMascotas.animales[mascotasArray[id].tipo]);

    btnAgregar.attr("value", "Modificar");
    btnAgregar.off("click", AgregarMascotas);
    btnAgregar.on("click", mod = function () { ModificarClick(id) });

}

function ModificarClick(id: number): void {
    let masc: practicaMascotas.Mascota = new practicaMascotas.Mascota(txtNombre.val(), txtEdad.val(), txtPatas.val(), selectTipo.val());
    mascotasArray[id] = JSON.parse(masc.toJson());
    localStorage.setItem("mascotas", JSON.stringify(mascotasArray));
    restaurarTexto();
    TraerMascotas();
    btnAgregar.attr("value", "Agregar");
    btnAgregar.off("click", mod);
    btnAgregar.on("click", AgregarMascotas);
}

function restaurarTexto() {
    txtNombre.val("");
    txtEdad.val("");
    txtPatas.val("");
    selectTipo.val("");
}



// function AgregarMascotaserver()
// {
//     $.ajax({
//         url : "http://localhost:3000/agregarMascotas",
//         data : { nombre: txtA.val(), apellido: txtB.val()},
//         type : "POST",
//         datatype : "text",
//         success : function(respuesta)
//         {
//             lblMensaje.html(respuesta).hide().fadeIn(2000).fadeOut(2000);
//         }
//     });
//     TraerMascotas();
//     restaurarTexto();
// }

// function EliminarMascotaserver(id)
// {
//     $.ajax({
//         url: "http://localhost:3000/eliminarMascotas",
//         data: {indice : id},
//         type : "POST",
//         dataType : "text",
//         success : function(respuesta)
//                 {
//                     lblMensaje.html(respuesta).hide().fadeIn(2000).fadeOut(2000);
//                 }
//     });

//     TraerMascotas();
// }

// function Eliminar(id) 
// {
//     EliminarMascotaserver(id);
//     MostrarMensaje("Se elimino la Mascotas"); 
// }



// function MostrarMensajeError(mensajeDeError)
// {
//     txtA.css("borderColor","red");
//     txtB.css("borderColor","red");
//     lblMensaje.css("color", "#FA2222");
//     lblMensaje.html(mensajeDeError);
// }

// function MostrarMensaje(mensaje)
// {
//     lblMensaje.css("color", "gray");
//     lblMensaje.html(mensaje);
// }

// function restaurarBorderColor() 
// {
//     txtA.css("borderColor","");
//     txtB.css("borderColor","");
//     lblMensaje.html("");
// }




// function CargarMascotas(respuesta) {
//     var Mascotas = respuesta;
//     lblMensaje.html("");
//     table.html("<tr><th>Nombre</th><th>Apellido</th><th>Accion</th></tr>");

//     for (var index= 0; index < Mascotas.length; index++) 
//     {
//         table.append("<tr><td name=n"+index+">"+Mascotas[index].nombre+"</td><td name=a"+index+">"+Mascotas[index].apellido+"</td>"+
//         "<td><input type=button id= "+index+" value=Eliminar onclick=Eliminar("+index+")>"+
//         "<input type=button id= "+index+" value=Modificar onclick=Modificar("+index+")></td></tr>");
//     }
// }

// function CargarMascotas()
// {
//     table.html("");
//     table.style = "block";
//     var Mascotas = JSON.parse(xhr.response);
//     for (var index= 0; index < Mascotas.length; index++) 
//     {
//         table.html("<tr><td name=n"+index+">"+Mascotas[index].nombre+"</td><td name=a"+index+">"+Mascotas[index].apellido+"</td>"+
//         "<td><input type=button id= "+index+" value=Eliminar onclick=Eliminar("+index+")>"+
//         "<input type=button id= "+index+" value=Modificar onclick=Modificar("+index+")></td></tr>");
//     }
// }