<?php
require_once 'usuario.php';
//require_once 'IApiUsable.php';

class usuarioApi extends usuario //implements IApiUsable
{


	public function TraerUno($request, $response, $args) 
	{
			$id = $args['id'];
			$elUsuario = usuario::TraerUnUsuario($id);
			$newResponse = $response->withJson($elUsuario, 200);  
			return $newResponse;
	}
	
	public function traerTodos($request, $response, $args) 
	{
			$todosLosUsuarios = usuario::TraerTodosLosUsuarios();
			$response = $response->withJson($todosLosUsuarios, 200);  
			return $response;
	}
	



	public function CargarUno($request, $response, $args) 
	{
			$ArrayDeParametros = $request->getParsedBody();
			$nombre = $ArrayDeParametros['nombre'];
			$email = $ArrayDeParametros['email'];
			$edad = $ArrayDeParametros['edad'];
			$perfil = $ArrayDeParametros['perfil'];
			$clave = $ArrayDeParametros['clave'];
			
			$miUsuario = new usuario();
			$miUsuario->nombre=$nombre;
			$miUsuario->email=$email;
			$miUsuario->edad=$edad;
			$miUsuario->perfil=$perfil;
			$miUsuario->clave=$clave;

			$miUsuario->InsertarElUsuarioParametros();

			$response->getBody()->write("se guardo el usuario");

			return $response;
	}
	



	public function ModificarUno($request, $response, $args) 
	{
			$ArrayDeParametros = $request->getParsedBody();
		
			$usuarioAModificar = new usuario();
			$usuarioAModificar = $usuarioAModificar->TraerUnUsuarioPorMail($ArrayDeParametros['email']);
			if(isset($ArrayDeParametros['nombre']))
			{
				$usuarioAModificar->nombre = $ArrayDeParametros['nombre'];
			}

			if(isset($ArrayDeParametros['edad']))
			{
				$usuarioAModificar->edad = $ArrayDeParametros['edad'];
			}

			if(isset($ArrayDeParametros['perfil']))
			{
				$usuarioAModificar->perfil = $ArrayDeParametros['perfil'];
			}

			if(isset($ArrayDeParametros['clave']))
			{
				$usuarioAModificar->clave = $ArrayDeParametros['clave'];
			}

			$resultado =$usuarioAModificar->ModificarUsuarioParametros();
			$objDelaRespuesta= new stdclass();
			$objDelaRespuesta->resultado=$resultado;
			return $response->withJson($objDelaRespuesta, 200);		
	}




	public function BorrarUno($request, $response, $args) 
	{
			$ArrayDeParametros = $request->getParsedBody(); //form-urlencoded
			$id=$ArrayDeParametros['id'];
			$usuario= new usuario();
			$usuario->id=$id;
			$cantidadDeBorrados=$usuario->BorrarUsuario();

			$objDelaRespuesta= new stdclass();
			$objDelaRespuesta->cantidad=$cantidadDeBorrados;
			if($cantidadDeBorrados>0)
			{
					$objDelaRespuesta->resultado="El usuario con id: ".$id." fue eliminado exitosamente";
			}
			else
			{
				$objDelaRespuesta->resultado="no Borro nada!!!";
			}
			$newResponse = $response->withJson($objDelaRespuesta, 200);  
			return $newResponse;
	}
	


}