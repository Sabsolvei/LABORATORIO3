// Tipos
//var batman = "Bruce";
//var superman = "Clark";
//var existe = false;
let batman:string = "Bruce";
let superman = "Clark";
let existe:boolean = false;


// Tuplas
//var parejaHeroes = [batman,superman];
let parejaHeroes:[string, string] = [batman, superman];
//var villano = ["Lex Lutor",5,true];
let villano:[string, number,boolean] = ["Lex Lutor",5,true];

// Arreglos
var aliados = ["Mujer Maravilla","Acuaman","San", "Flash"];

//Enumeraciones
var fuerzaFlash = 5;
var fuerzaSuperman = 100;
var fuerzaBatman = 1;
var fuerzaAcuaman = 0;

enum

// Retorno de funciones
function activar_batiseñal(){
  return "activada";
}

function pedir_ayuda(){
  console.log("Auxilio!!!");
}

// Aserciones de Tipo
var poder = "100";
var largoDelPoder = poder.length;
console.log( largoDelPoder );
