class Avenger {
    private _nombre:string|undefined;
    nombreReal:string;
    peleasGanadas:number;

    constructor(peleasGanadas:number, nombreReal:string, nombre?:string|undefined)
    {
        this.nombreReal = nombreReal;
        this.peleasGanadas = peleasGanadas;   
        this._nombre = nombre;
    }

    mostrar():string{
        return `Nombre: ${this._nombre}, Nombre real: ${this.nombreReal}, Peleas ganadas: ${this.peleasGanadas}`;
    }

    //getter y setter
    get Nombre():string|undefined{
        return this._nombre;
    }
    set Nombre(nombre:string|undefined){
        this._nombre = nombre;
    }
}

class Xmen extends Avenger  {
    private _poder:number;

    constructor(pg:number, nr:string, p:number, n?:string|undefined){
        super(pg, nr, n)
        this._poder = p;
    }

    mostrar():string{
       return super.mostrar() + this._poder;
    }
}

class  Apocalipsis { //PATRON DE DISEÑO SINGLETON: permite instanciar SOLO UN objeto de esta clase
    private static _instance:Apocalipsis;//aca se guarda una referencia al objeto apocalipsis que se podra acceder de forma estatica

    private constructor(public nombre:string)//pasarle public hace que sea un atributo de la clase
    { 
    }

    //getter: mediante este getter se podra acceder desde afuera a esta clase
    static get Instance():Apocalipsis{  
        if(!(this._instance)){
            this._instance = new Apocalipsis("Heeeelll");
        }
        return this._instance;
    }

}

console.log(Apocalipsis.Instance.nombre);
//a1:Apocalipsis = new Apocalipsis(); //la instancia es privada, esto no se puede hacer
let a1 = new Avenger(10, "tony","ironman");
//a1.nombreReal = "Tomy";
// a1.peleasGanadas = 10;
console.log(a1.mostrar());
a1.Nombre = "TOMAS";
console.log(a1.Nombre);
//console.log(a1);
let x1:Xmen = new Xmen(10, "Xmen", 11);

let listaAvengers = new Array<Avenger>();
listaAvengers.push(a1);
listaAvengers.push(x1);
console.log(listaAvengers[0].nombreReal);