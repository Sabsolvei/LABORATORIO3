"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Avenger = /** @class */ (function () {
    function Avenger(peleasGanadas, nombreReal, nombre) {
        this.nombreReal = nombreReal;
        this.peleasGanadas = peleasGanadas;
        this._nombre = nombre;
    }
    Avenger.prototype.mostrar = function () {
        return "Nombre: " + this._nombre + ", Nombre real: " + this.nombreReal + ", Peleas ganadas: " + this.peleasGanadas;
    };
    Object.defineProperty(Avenger.prototype, "Nombre", {
        //getter y setter
        get: function () {
            return this._nombre;
        },
        set: function (nombre) {
            this._nombre = nombre;
        },
        enumerable: true,
        configurable: true
    });
    return Avenger;
}());
var Xmen = /** @class */ (function (_super) {
    __extends(Xmen, _super);
    function Xmen(pg, nr, p, n) {
        var _this = _super.call(this, pg, nr, n) || this;
        _this._poder = p;
        return _this;
    }
    Xmen.prototype.mostrar = function () {
        return _super.prototype.mostrar.call(this) + this._poder;
    };
    return Xmen;
}(Avenger));
var Apocalipsis = /** @class */ (function () {
    function Apocalipsis(nombre) {
        this.nombre = nombre;
    }
    Object.defineProperty(Apocalipsis, "Instance", {
        //getter: mediante este getter se podra acceder desde afuera a esta clase
        get: function () {
            if (!(this._instance)) {
                this._instance = new Apocalipsis("Heeeelll");
            }
            return this._instance;
        },
        enumerable: true,
        configurable: true
    });
    return Apocalipsis;
}());
console.log(Apocalipsis.Instance.nombre);
//a1:Apocalipsis = new Apocalipsis(); //la instancia es privada, esto no se puede hacer
var a1 = new Avenger(10, "tony", "ironman");
//a1.nombreReal = "Tomy";
// a1.peleasGanadas = 10;
console.log(a1.mostrar());
a1.Nombre = "TOMAS";
console.log(a1.Nombre);
//console.log(a1);
var x1 = new Xmen(10, "Xmen", 11);
var listaAvengers = new Array();
listaAvengers.push(a1);
listaAvengers.push(x1);
console.log(listaAvengers[0].nombreReal);
