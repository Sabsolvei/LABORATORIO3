// function enviarMisionAny(xmen:any){
//     console.log(xmen.nombre);
// }

// function enviarMision(xmen:{nombre:string}){ //asi me garantizo que el objeto traiga un atributo llamado "nombre"
//     console.log(xmen.nombre);
// }

// let xmen = {
//     nombre: "Ciclope",
//     peleasGanadas: 4

// }

// enviarMisionAny(xmen);

interface IXmen{
nombre:string;
peleasGanadas:number;
otroAtributo:string;

}


class xm implements IXmen
{
    miMetodo(nombre:string)    {
        return "Holaaaaaaaaaaaaaaaaa";
    }
    nombre:string;
    peleasGanadas:number;
    otroAtributo:string;
}
let xmen:Xmen = new Xmen(12, "dsfds", 23, "sdf");
let xmen2:xm = new xm();
console.log(xmen2.miMetodo(xmen.nombreReal));





