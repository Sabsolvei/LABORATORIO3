"use strict";
// function enviarMisionAny(xmen:any){
//     console.log(xmen.nombre);
// }
var xm = /** @class */ (function () {
    function xm() {
    }
    xm.prototype.miMetodo = function (nombre) {
        return "Holaaaaaaaaaaaaaaaaa";
    };
    return xm;
}());
var xmen = new Xmen(12, "dsfds", 23, "sdf");
var xmen2 = new xm();
console.log(xmen2.miMetodo(xmen.nombreReal));
