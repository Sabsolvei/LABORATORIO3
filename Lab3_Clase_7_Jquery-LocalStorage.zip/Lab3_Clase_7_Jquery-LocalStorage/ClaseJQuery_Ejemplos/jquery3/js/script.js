$(function(){

   var cartel = $(".cartel");

   cartel
   .width(450)
   .height(450)
   .text("Chau")
   .hide()
   .fadeIn(5000);


});

